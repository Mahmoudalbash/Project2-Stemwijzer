<?php
include 'config.php';
include 'Stemwijzer.php';

$stemwijzer = new Stemwijzer();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $vraag = $_POST['vraag'];

    $stmt = $stemwijzer->pdo->prepare("UPDATE vragen SET vraag=:vraag WHERE id=:id");
    $stmt->bindParam(':vraag', $vraag);
    $stmt->bindParam(':id', $id);

    if ($stmt->execute()) {
        header("Location: manage_questions.php");
    } else {
        echo "Error: " . $stmt->errorInfo();
    }
} else {
    $id = $_GET['id'];
    $stmt = $stemwijzer->pdo->prepare("SELECT * FROM vragen WHERE id=:id");
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Vraag Bewerken</title>
</head>
<body>
    <h1>Vraag Bewerken</h1>
    <form method="post" action="">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
        Vraag: <input type="text" name="vraag" value="<?php echo $row['vraag']; ?>"><br>
        <input type="submit" value="Bijwerken">
    </form>
    <a href="manage_questions.php">Terug</a>
</body>
</html>

