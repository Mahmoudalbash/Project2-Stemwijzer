<?php
include 'Stemwijzer.php';

$stemwijzer = new Stemwijzer();
$vragen = $stemwijzer->selectAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Stemwijzer</title>
</head>
<body>
    <h1>Stemwijzer</h1>
    <form action="result.php" method="post">
        <?php
        foreach ($vragen as $row) {
            echo "<p>" . $row["vraag"] . "</p>";
            echo "<input type='radio' name='vraag_" . $row["id"] . "' value='eens'> Eens<br>";
            echo "<input type='radio' name='vraag_" . $row["id"] . "' value='oneens'> Oneens<br>";
            echo "<input type='radio' name='vraag_" . $row["id"] . "' value='weet niet'> Weet ik niet<br>";
        }
        ?>
        <input type="submit" value="Verstuur">
    </form>
</body>
</html>

