<?php
include 'Stemwijzer.php';

$stemwijzer = new Stemwijzer();
$partijen = $stemwijzer->selectParties();

$antwoorden = [];
foreach ($_POST as $key => $value) {
    $antwoorden[] = $value;
}

$scores = [];
foreach ($partijen as $partij) {
    $standpunten = explode(",", $partij['standpunten']);
    $score = 0;
    foreach ($standpunten as $index => $standpunt) {
        if ($antwoorden[$index] == $standpunt) {
            $score++;
        }
    }
    $scores[$partij['naam']] = $score;
}

arsort($scores);
$beste_partij = key($scores);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Resultaat</title>
</head>
<body>
    <h1>Uw Resultaat</h1>
    <p>De partij die het beste bij u past is: <strong><?php echo $beste_partij; ?></strong></p>
    <a href="index.php">Terug naar de vragen</a>
</body>
</html>

