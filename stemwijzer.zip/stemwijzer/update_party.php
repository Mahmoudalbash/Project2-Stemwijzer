<?php
include 'config.php';
include 'Stemwijzer.php';

$stemwijzer = new Stemwijzer();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $naam = $_POST['naam'];
    $standpunten = $_POST['standpunten'];

    $stmt = $stemwijzer->pdo->prepare("UPDATE politieke_partijen SET naam=:naam, standpunten=:standpunten WHERE id=:id");
    $stmt->bindParam(':naam', $naam);
    $stmt->bindParam(':standpunten', $standpunten);
    $stmt->bindParam(':id', $id);

    if ($stmt->execute()) {
        header("Location: manage_parties.php");
    } else {
        echo "Error: " . $stmt->errorInfo();
    }
} else {
    $id = $_GET['id'];
    $stmt = $stemwijzer->pdo->prepare("SELECT * FROM politieke_partijen WHERE id=:id");
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Partij Bewerken</title>
</head>
<body>
    <h1>Partij Bewerken</h1>
    <form method="post" action="">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
        Naam: <input type="text" name="naam" value="<?php echo $row['naam']; ?>"><br>
        Standpunten (gescheiden door komma's): <input type="text" name="standpunten" value="<?php echo $row['standpunten']; ?>"><br>
        <input type="submit" value="Bijwerken">
    </form>
    <a href="manage_parties.php">Terug</a>
</body>
</html>

