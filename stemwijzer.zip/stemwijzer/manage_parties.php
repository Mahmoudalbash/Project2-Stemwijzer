<?php
include 'config.php';
include 'Stemwijzer.php';

$stemwijzer = new Stemwijzer();
$partijen = $stemwijzer->selectParties();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Partijen Beheren</title>
</head>
<body>
    <h1>Partijen Beheren</h1>
    <a href="create_party.php">Nieuwe Partij Toevoegen</a>
    <table border="1">
        <tr>
            <th>Naam</th>
            <th>Standpunten</th>
            <th>Acties</th>
        </tr>
        <?php
        foreach ($partijen as $row) {
            echo "<tr>
                    <td>" . $row["naam"]. "</td>
                    <td>" . $row["standpunten"] . "</td>
                    <td>
                        <a href='update_party.php?id=" . $row["id"] . "'>Bewerken</a>
                        <a href='delete_party.php?id=" . $row["id"] . "'>Verwijderen</a>
                    </td>
                  </tr>";
        }
        ?>
    </table>
    <a href="logout.php">Uitloggen</a>
    <a href="index.php">Terug naar de stemwijzer</a>
</body>
</html>

