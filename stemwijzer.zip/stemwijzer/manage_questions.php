<?php
include 'config.php';
include 'Stemwijzer.php';

$stemwijzer = new Stemwijzer();
$vragen = $stemwijzer->selectAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Vragen Beheren</title>
</head>
<body>
    <h1>Vragen Beheren</h1>
    <a href="create_question.php">Nieuwe Vraag Toevoegen</a>
    <table border="1">
        <tr>
            <th>Vraag</th>
            <th>Acties</th>
        </tr>
        <?php
        foreach ($vragen as $row) {
            echo "<tr>
                    <td>" . $row["vraag"]. "</td>
                    <td>
                        <a href='update_question.php?id=" . $row["id"] . "'>Bewerken</a>
                        <a href='delete_question.php?id=" . $row["id"] . "'>Verwijderen</a>
                    </td>
                  </tr>";
        }
        ?>
    </table>
    <a href="logout.php">Uitloggen</a>
    <a href="index.php">Terug naar de stemwijzer</a>
</body>
</html>



